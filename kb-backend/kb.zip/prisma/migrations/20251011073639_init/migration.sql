-- AlterTable
ALTER TABLE `kbpost` ADD COLUMN `category` VARCHAR(191) NULL;
